import { fruit, country, animal } from './higherOrderandClousre.js';

console.log(fruit('Apple'));
console.log(animal('Tiger'));
console.log(country('USA'));